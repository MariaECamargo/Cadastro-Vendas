<!-- resources/views/produtos/criar.blade.php -->

@extends('layouts.app')

@section('cadastro')
    <h2>Cadastro de Produto</h2>

    @if(session('sucesso'))
        <div class="alert alert-success">
            {{ session('sucesso') }}
        </div>
    @endif

    <form method="POST" action="{{ route('produto.loja') }}">
        @csrf
        <div class="mb-3">
            <label for="nome" class="form-label">Nome do Produto</label>
            <input type="text" class="form-control" id="nome" name="nome" required>
        </div>
        <div class="mb-3">
            <label for="descricao" class="form-label">Descrição</label>
            <textarea class="form-control" id="descricao" name="descricao" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="quantidade" class="form-label">Quantidade</label>
            <input type="number" class="form-control" id="quantidade" name="quantidade" required>
        </div>
        <div class="mb-3">
            <label for="valor" class="form-label">Valor</label>
            <input type="text" class="form-control" id="valor" name="valor" required>
        </div>
        <div class="mb-3">
            <label for="categoria" class="form-label">Categoria</label>
            <input type="text" class="form-control" id="categoria" name="categoria" required>
        </div>
        <div class="mb-3">
            <label for="origem" class="form-label">Origem</label>
            <select class="form-select" id="origem" name="origem" required>
            <option value="" selected disabled>Selecione o Estado ou País</option>
                @foreach($estados as $estado)
                    <option value="{{ $estado }}">{{ $estado }}</option>
                @endforeach
                <option value="Internacional">Internacional</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Cadastrar</button>
    </form>
@endsection
