<?php

use App\Http\Controllers\AppController;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\ProdutoController;



//Rota para listar todos os usuarios
Route::get('/usuarios', [UsuarioController::class,'index'])->name('usuarios.index');

//rota que direciona para a página que tem o formulario de cadastro
Route::get('/usuarios/cadastro', [UsuarioController::class,'cadastro'])->name('usuarios.cadastro');

//Rota que direciona para o processamento do formulário
Route::post('/usuarios/novo', [UsuarioController::class,'novo'])->name('usuarios.novo');


//Rota para chamar tela de login
Route::get('/telalogin', [AppController::class,'telaLogin'])->name('tela.login'); 

//Rota para chamar a função de fazer login
Route::get('/login', [AppController::class, 'login'])->name('login');

//Rota para acessar a tela de alteração de usuario
Route::get('/usuario/alterar/{id}', [UsuarioController::class,'telaAlteracao'])->name('usuario.atualiza'); 

//Rota para alterar o cadastro do usuario
Route::post('/usuario/alterar/{id}', [UsuarioController::class,'alterar'])->name('usuario.alterar'); 

//Rota para excluir o usuario
Route::get('/usuario/excluir/{id}', [UsuarioController::class,'excluir'])->name('usuario.excluir'); 


//Rota para listar todos os produtos
Route::get('/produto', [ProdutoController::class, 'index'])->name('produto.index');

// criar produto
Route::get('/produto/criar', [ProdutoController::class, 'criar'])->name('produto.criar');

Route::post('/produto/loja', [ProdutoController::class, 'loja'])->name('produto.loja');

//editar produto
Route::get('/produto/{id}/editar', [ProdutoController::class, 'editar'])->name('produto.editar');

// atualizar produto
Route::PUT('/produto/{id}/update', [ProdutoController::class, 'update'])->name('produto.update');

//deletar produto
Route::delete('/produto/{id}/deletar', [ProdutoController::class, 'deletar'])->name('produto.deletar');

use App\Http\Controllers\vendaController;

Route::get('/vendas', [vendaController::class, 'telaCadastro'])-> name('venda.cadastro');

Route::post('/vendas/novo', [vendaController::class, 'novo'])->name('venda.novo');

Route::get('/venda/usuario/{id}', [vendaController::class, 'vendaPorUsuario'])->name('venda.usuario');

