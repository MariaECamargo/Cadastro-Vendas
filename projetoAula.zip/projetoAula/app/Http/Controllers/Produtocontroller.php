<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Produto;

class Produtocontroller extends Controller
{
    public function index(){
        $produtos = Produto::all();
        return view('produtos.index',compact('produtos'));
    }
    public function criar(){
        $estados = [
            'Acre', 'Alagoas', 'Amapá', 'Amazonas', 'Bahia', 'Ceará', 'Distrito Federal',
            'Espírito Santo', 'Goiás', 'Maranhão', 'Mato Grosso', 'Mato Grosso do Sul',
            'Minas Gerais', 'Pará', 'Paraíba', 'Paraná', 'Pernambuco', 'Piauí',
            'Rio de Janeiro', 'Rio Grande do Norte', 'Rio Grande do Sul', 'Rondônia',
            'Roraima', 'Santa Catarina', 'São Paulo', 'Sergipe', 'Tocantins'
        ];
    
        return view('produtos.criar', compact('estados'));
    }
    public function loja(Request $request){
        $produto = new Produto($request->all());
        $produto->save();

        return redirect()->route('produto.index')->with('sucesso', 'Produto cadastrado com sucesso!');
    }
    public function editar($id)
{
    $produto = Produto::findOrFail($id);

    $estados = [
        'Acre', 'Alagoas', 'Amapá', 'Amazonas', 'Bahia', 'Ceará', 'Distrito Federal',
        'Espírito Santo', 'Goiás', 'Maranhão', 'Mato Grosso', 'Mato Grosso do Sul',
        'Minas Gerais', 'Pará', 'Paraíba', 'Paraná', 'Pernambuco', 'Piauí',
        'Rio de Janeiro', 'Rio Grande do Norte', 'Rio Grande do Sul', 'Rondônia',
        'Roraima', 'Santa Catarina', 'São Paulo', 'Sergipe', 'Tocantins'
    ];

    return view('produtos.editar', compact('produto', 'estados'));
}

public function update(Request $request, $id)
{
    $produto = Produto::findOrFail($id);
    $produto->update($request->all());

    return redirect()->route('produto.index')->with('sucesso', 'Produto atualizado com sucesso!');
}

public function deletar($id)
{
    $produto = Produto::findOrFail($id);
    $produto->delete();

    return redirect()->route('produto.index')->with('sucesso', 'Produto excluído com sucesso!');
}
}
