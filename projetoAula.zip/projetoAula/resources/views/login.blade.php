@extends('layouts.app')

@section('login')
    <div class="container"> 
        <form action="{{ route('login') }}" method="get">
            @csrf 
            <div class="form-group">
                <label for="usuario">Nome do Usuário</label>
                <input type="text" class="form-control" id="usuario" placeholder="Digite seu usuário" name="login">
            </div>

            <div class="form-group">
                <label for="senha">Senha</label>
                <input type="password" name="senha" id="senha" placeholder="Digite sua senha">
            </div>

            <button type="submit" class="btn btn-primary">Entrar</button>
        </form>

       
    </div>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if(Auth::check())
        <div class="mt-3">
            <p>Escolha para onde ir após o login:</p>
            <ul>
                <li><a href="{{ route('usuarios.index') }}">Ir para Usuários</a></li>
                <li><a href="{{ route('produtos.index') }}">Ir para Produtos</a></li>
            </ul>
        </div>
    @endif
@endsection
