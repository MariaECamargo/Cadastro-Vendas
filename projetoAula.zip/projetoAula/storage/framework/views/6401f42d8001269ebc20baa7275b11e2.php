
<?php $__env->startSection('venda.cadastro'); ?>

<h1>Cadastro de Venda</h1>
<form method="post" action="<?php echo e(route('venda.novo')); ?>">
    <?php echo csrf_field(); ?>
    <select class="form-control" name="id_usuario">
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($u-> id); ?>">{{}$u ->nome}</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="number" class="form-control" name="valor" placeholder="Valor">
    <input type="submit" class="btn btn-success" value="Enviar">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoAula\resources\views/vendas/cadastro.blade.php ENDPATH**/ ?>